import * as React from "react";
export interface CurrencyProps { rows: Array<Row>; }
interface Row {
    date:string;
    open:string;
    high:string;
    low:string;
    close:string;
    volume:string;
}
// 'CurrencyProps' describes the shape of props.
// State is never set so we use the '{}' type.
export class CurrencyTable extends React.Component<CurrencyProps, {}> {

    render() {
        return (
        <table className="table">
            {
                this.props.rows.map((row:any,index:number)=>{
                    let cards:Array<object> = [],body;
                    
                    if(index == 0) {
                        for(let value in row) {
                                cards.push(
                                    <th scope="col">
                                        {row[value]}
                                    </th>
                                    );
                        }
                        body = <thead><tr>{cards}</tr></thead>;
                    }
                    else {
                        for(let value in row) {
                            cards.push(
                                <td>
                                    {row[value]}
                                </td>
                                );
                    }
                    body = <tbody><tr>{cards}</tr></tbody>;
                    }
                    return body;
                })
            }
        </table>
        )
      ;
    }
}
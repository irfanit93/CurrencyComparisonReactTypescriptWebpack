import "react";
import "react-dom";
import * as React from "react";
import * as ReactDOM from "react-dom";
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap';

import { Hello } from "./Hello/Hello";
import {CurrencyCards} from './CurrencyCards/CurrencyCards';
import { CurrencyTable } from "./CurrencyTable/CurrencyTable";

interface ToggleState { isOn:Boolean; }

let Cards:any = [{
    date:   "date",
    open:   "open",
    high:   "high",
    low:    "low",
    close:  "close",
    volume: "volume"
},
{
    date:   "Sep 04, 2019",
    open:   "1235",
    high:   "7458",
    low:    "5689",
    close:  "32568",
    volume: "78452"
},
{
    date:   "Sep 04, 2019",
    open:   "1235",
    high:   "7458",
    low:    "5689",
    close:  "32568",
    volume: "78452"
},
{
    date:   "Sep 04, 2019",
    open:   "1235",
    high:   "7458",
    low:    "5689",
    close:  "32568",
    volume: "78452"
}
];



class  Toggle extends React.Component<{},ToggleState> {
    constructor(props: Readonly<{}>) {
        super(props);
        this.state = {
            isOn : true
        };
    }

    render(){
        return ( 
            <>
            {this.state.isOn ? <CurrencyCards rows = {Cards}/> : <CurrencyTable rows = {Cards}/>}
            <button type="button" className="btn btn-primary" onClick={()=>{this.setState({isOn: !this.state.isOn})}}>Toggle</button>
            </>
            );
    }
}

ReactDOM.render(
    <div className="container-fluid text-center">
        <Hello heading="Currency" smiley=" Values Comparison" />
        <Toggle/>
    </div>,
    document.getElementById("root")
);
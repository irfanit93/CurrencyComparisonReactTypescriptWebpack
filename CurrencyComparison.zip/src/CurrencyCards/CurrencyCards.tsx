import * as React from "react";
export interface CurrencyProps { rows: Array<Row>; }
interface Row {
    date:string;
    open:string;
    high:string;
    low:string;
    close:string;
    volume:string;
}
// 'CurrencyProps' describes the shape of props.
// State is never set so we use the '{}' type.
export class CurrencyCards extends React.Component<CurrencyProps, {}> {

    render() {
        return (
        <div className="row">
            {
                this.props.rows.map((row:any)=>{
                    let cards:Array<object> = [];
                    for(let value in row)
                    {
                            cards.push(
                                <div className="col-2">
                                    <div className="card">
                                        <div className="card-body">
                                            <h5 className="card-title">{row[value]}</h5>
                                        </div>
                                    </div>
                                </div>
                                );
                    }
                    return cards;
                })
            }
        </div>
        )
      ;
    }
}